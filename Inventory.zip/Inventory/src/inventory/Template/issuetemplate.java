/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.Template;

/**
 *
 * @author SIMI
 */
public class issuetemplate {
  String department,stocktype,issueto,teacher,name,monthofissue;
  int dateofissue,yearofissue;

    public int getDateofissue() {
        return dateofissue;
    }

    public void setDateofissue(int dateofissue) {
        this.dateofissue = dateofissue;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getIssueto() {
        return issueto;
    }

    public void setIssueto(String issueto) {
        this.issueto = issueto;
    }

    public String getMonthofissue() {
        return monthofissue;
    }

    public void setMonthofissue(String monthofissue) {
        this.monthofissue = monthofissue;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStocktype() {
        return stocktype;
    }

    public void setStocktype(String stocktype) {
        this.stocktype = stocktype;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public int getYearofissue() {
        return yearofissue;
    }

    public void setYearofissue(int yearofissue) {
        this.yearofissue = yearofissue;
    }
}
