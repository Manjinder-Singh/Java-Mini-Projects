/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.Template;

/**
 *
 * @author SIMI
 */
public class yeartemplate {
    int year;

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

  
}
