/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.Template;

/**
 *
 * @author SIMI
 */
public class lab {
    String department,labs;

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getLabs() {
        return labs;
    }

    public void setLabs(String labs) {
        this.labs = labs;
    }
    
}
