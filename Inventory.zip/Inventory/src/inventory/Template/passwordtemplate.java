/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.Template;

/**
 *
 * @author SIMI
 */
public class passwordtemplate {
    String newpassword,confirmnewpassword;

    public String getConfirmnewpassword() {
        return confirmnewpassword;
    }

    public void setConfirmnewpassword(String confirmnewpassword) {
        this.confirmnewpassword = confirmnewpassword;
    }

    public String getNewpassword() {
        return newpassword;
    }

    public void setNewpassword(String newpassword) {
        this.newpassword = newpassword;
    }
}
   

   

    

   
 
