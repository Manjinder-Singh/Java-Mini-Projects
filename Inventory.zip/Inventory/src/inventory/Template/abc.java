/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.Template;

/**
 *
 * @author SIMI
 */
public class abc {
    String name,company,product,stocktype,companyaddress,modelno,contact;
   int noofitems,priceperpiece,warranty,dateofmanufacture,dateofpurchase;
   String monthofmanufacture,monthofpurchase;
int yearofmanufacture,yearofpurchase;


    public String getCompanyaddress() {
        return companyaddress;
    }

    public void setCompanyaddress(String companyaddress) {
        this.companyaddress = companyaddress;
    }
  

    public String getMonthofmanufacture() {
        return monthofmanufacture;
    }

    public void setMonthofmanufacture(String monthofmanufacture) {
        this.monthofmanufacture = monthofmanufacture;
    }

    public String getMonthofpurchase() {
        return monthofpurchase;
    }

    public void setMonthofpurchase(String monthofpurchase) {
        this.monthofpurchase = monthofpurchase;
    }

    public int getYearofmanufacture() {
        return yearofmanufacture;
    }

    public void setYearofmanufacture(int yearofmanufacture) {
        this.yearofmanufacture = yearofmanufacture;
    }

    public int getYearofpurchase() {
        return yearofpurchase;
    }

    public void setYearofpurchase(int yearofpurchase) {
        this.yearofpurchase = yearofpurchase;
    }

    
  
   

    public String getCompany() {
        return company;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    

   

   


    public String getStocktype() {
        return stocktype;
    }

    public void setStocktype(String stocktype) {
        this.stocktype = stocktype;
    }

    public void setCompany(String company) {
        this.company = company;
    }

   



    public String getModelno() {
        return modelno;
    }

    public void setModelno(String modelno) {
        this.modelno = modelno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    
           
}

    public int getDateofmanufacture() {
        return dateofmanufacture;
    }

    public void setDateofmanufacture(int dateofmanufacture) {
        this.dateofmanufacture = dateofmanufacture;
    }

    public int getDateofpurchase() {
        return dateofpurchase;
    }

    public void setDateofpurchase(int dateofpurchase) {
        this.dateofpurchase = dateofpurchase;
    }

    public int getNoofitems() {
        return noofitems;
    }

    public void setNoofitems(int noofitems) {
        this.noofitems = noofitems;
    }

    public int getPriceperpiece() {
        return priceperpiece;
    }

    public void setPriceperpiece(int priceperpiece) {
        this.priceperpiece = priceperpiece;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public int getWarranty() {
        return warranty;
    }

    public void setWarranty(int warranty) {
        this.warranty = warranty;
    }

   
}