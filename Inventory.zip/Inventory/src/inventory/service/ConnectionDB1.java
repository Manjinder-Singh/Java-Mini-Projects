/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.service;

import com.mongodb.DB;
import com.mongodb.MongoClient;

/**
 *
 * @author SIMI
 */
public class ConnectionDB1 {
    public static DB conDB()
    {
    MongoClient mongo=new MongoClient("localhost",27017);
    DB db = mongo.getDB("demo");
    return db;
}
}