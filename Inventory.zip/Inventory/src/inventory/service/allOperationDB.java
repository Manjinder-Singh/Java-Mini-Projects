/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.service;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;

/**
 *
 * @author SIMI
 */
public class allOperationDB {
     DB db;
   public allOperationDB()//constructor call first
    {
        db=ConnectionDB.conDB();//return type db than return database
        
    }
   public DBCursor searchrequire(String department, String types)
   {
     DBCollection table=db.getCollection("stock");
     BasicDBObject searchquery=new BasicDBObject();
     searchquery.put("department",department);
     searchquery.put("types",types);
     //Shows the rows of a table
     BasicDBList list=new BasicDBList();
     list.add(searchquery);
     
     BasicDBObject search=new BasicDBObject();
     search.put("$and", list);
     
     DBCursor cursor=table.find(search);
     return cursor;
    }
 }