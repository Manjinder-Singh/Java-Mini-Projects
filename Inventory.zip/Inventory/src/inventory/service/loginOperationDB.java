/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.service;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import inventory.Template.logintemplate;

/**
 *
 * @author SIMI
 */
public class loginOperationDB {
    DB db;
    public loginOperationDB()
    
         {
        db=ConnectionDB.conDB();//return type db than return database
        
    }
    public void Savelogin(logintemplate T)
    {
        DBCollection table=db.getCollection("password");//collection enteries
     BasicDBObject document=new BasicDBObject();//create documentthn enter info
    
            document.put("password",T.getPassword());
               document.put("username",T.getUsername());
               table.insert(document);
    }
    
}
