/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.service;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.WriteResult;
import inventory.Template.abc;

/**
 *
 * @author SIMI
 */
public class Stock1OperationDB {
    
    DB db;
   public Stock1OperationDB()//constructor call first
    {
        db=ConnectionDB.conDB();//return type db than return database
        
    }
    public void SaveStock(abc T)
    {
       
     DBCollection table=db.getCollection("stock_record");//collection enteries
     BasicDBObject document=new BasicDBObject();//create documentthn enter info
     System.out.println(T.getCompany());
            document.put("modelno",T.getModelno());
               document.put("stocktype",T.getStocktype());
     document.put("name",T.getName());
      document.put("noofitems",T.getNoofitems());
       document.put("priceperpiece",T.getPriceperpiece());
              document.put("dateofpurchase",T.getDateofpurchase());
               document.put("monthofpurchase",T.getMonthofpurchase());
           document.put("yearofpurchase",T.getYearofpurchase());
           
      document.put("product",T.getProduct());
      document.put("company",T.getCompany());
      document.put("companyaddress",T.getCompanyaddress());
             document.put("contact",T.getContact());
       
        
       
           document.put("dateofmanufacture",T.getDateofmanufacture());
              document.put("monthofmanufacture",T.getMonthofmanufacture());
           document.put("yearofmanufacture",T.getYearofmanufacture());
        
               
                document.put("warranty",T.getWarranty());
 
              
                   
                                
        //document.put("item",T.getItem());
      table.insert(document); //insert document in it
     
    //     DBCollection table= db.getCollection("user");
    
    }
    public void updateStock(abc T)
    {
        //mongo query update record on behalf of modelno.
        DBCollection table=db.getCollection("stock_record");
        BasicDBObject query=new BasicDBObject();
        query.put("modelno",T.getModelno());
    
    
         BasicDBObject Document=new BasicDBObject();
         Document.put("name",T.getName());
         Document.put("noofitems",T.getNoofitems());
         Document.put("priceperpiece",T.getPriceperpiece());
         Document.put("contact",T.getContact());
         
          Document.put("stocktype",T.getStocktype());
    
              Document.put("dateofpurchase",T.getDateofpurchase());
               Document.put("monthofpurchase",T.getMonthofpurchase());
           Document.put("yearofpurchase",T.getYearofpurchase());
           
      Document.put("product",T.getProduct());
      Document.put("company",T.getCompany());
      Document.put("companyaddress",T.getCompanyaddress());
           
       
        
       
           Document.put("dateofmanufacture",T.getDateofmanufacture());
              Document.put("monthofmanufacture",T.getMonthofmanufacture());
           Document.put("yearofmanufacture",T.getYearofmanufacture());
        
               
                Document.put("warranty",T.getWarranty());
 
              
              
         
          BasicDBObject UpdateObj=new BasicDBObject();
          UpdateObj.put("$set", Document);
          
          
          table.update(query, UpdateObj);
     
    }   
    
    

    
public DBCursor searchStock(String modelno)
{
    System.out.println(modelno);
    DBCollection table=db.getCollection("stock_record");
     BasicDBObject searchquery=new BasicDBObject();
     searchquery.put("modelno",modelno);
     DBCursor cursor=table.find(searchquery);
     return cursor;
     
//     while(cursor.hasNext())
//             {
//                DBObject dbo= cursor.next();
//                System.out.println(dbo.get("product"));
//             }
}

    public DBCursor searchStockType(String hardware) {
        DBCollection table=db.getCollection("stock_record");
     BasicDBObject searchquery=new BasicDBObject();
     searchquery.put("hardware",hardware);
     DBCursor cursor=table.find(searchquery);
     return cursor;
    }

}


