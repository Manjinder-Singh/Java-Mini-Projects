public class newthread implements Runnable     //Runnable inbuilt interface
{
	Thread t;  //Thread inbuilt class
	String mythread;
	boolean suspended=false;

	newthread(String a) //parametrized constructor
	{
	mythread=a;
	System.out.println("creating in constructor:-> "+mythread);
	}
public int Run ()
{
System.out.println("running run function:-> " +mythread);
try
{
for(int i=0;i<5;i++)
{
Thread.sleep(2000);
synchronized(this)
{
while(suspended)
{
wait();
}
}
}
}

catch(InterruptedException e)
{
System.out.println("Thread in catch"+mythread+"interuption");
}
}
int start()
{
System.out.println("Start function" +mythread);
if(t==null)
{
t=new Thread(this,mythread);
t.start();
}
}
int suspend()
{
suspended=true;
}
synchronized void resume()
{
suspended=false;
notify();
}
}




class testing
{
public static void main(String args[])
{
newthread obj=new newthread("mythread 1");
obj.start();
newthread obj1=new newthread("mythread 2");
obj1.start();

try
{
Thread.sleep(1000);
obj.suspend ();
System.out.println("Suspending First Thread");
Thread.sleep(1000);
obj.resume ();
System.out.println("Resuming First Thread");
obj1.suspend ();
System.out.println("Suspending thread Two");

Thread.sleep(1000);
obj1.resume ();
System.out.println("Resuming thread Two");
} 
catch (InterruptedException e)
 {
System.out.println("1st catch Main thread Interrupted");
}
try 
{
System.out.println("2nd try Waiting for threads to finish.");
obj.t.join();
obj1.t.join();
} 
catch (InterruptedException e)
 {
System.out.println("2nd catchMain thread Interrupted ");
}
System.out.println(" Main thread exiting.");
}
}
