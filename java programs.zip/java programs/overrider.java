//3
//use of super keyword in over riding
//super is declared with method name of parent class in method of child class
class parent
{
void name()
{
System.out.println("parent");
}
void roll()
{
System.out.println("roll");
}
}
 
class child extends parent
{
/*void name()
{
super.name();
System.out.println("child");
super.name();

}*/
}
class overrider
{
public static void main(String args[])
{
parent obj=new parent();
parent obj1=new child(); 
child obj2 =new child();

obj.name();

System.out.println();

System.out.println();
System.out.println();
obj1.name();
System.out.println();
System.out.println();
obj2.name();
obj.roll();
obj1.roll();
obj2.roll();
}
}