//An abstract method is a method that is declared, but contains no implementation. Abstract classes may not be instantiated, and require subclasses 
//to provide implementations for the abstract methods. Let's look at an example of an abstract class, and an abstract method.



class newthread implements Runnable     //Runnable inbuilt interface
{
	Thread t;  			//Thread inbuilt class
	String mythread;
	boolean suspended=false;

	newthread(String a) 		//parametrized constructor
	{
	mythread=a;
	System.out.println("creating in constructor:-> "+mythread);
	}

public void run ()			//thread function
{
	System.out.println("running run function:-> " +mythread);
try
{
for(int i=0;i<5;i++)
{
Thread.sleep(2000);		//2 sec delay
synchronized(this)		//so that no 2 threads at the same time write 
{
while(suspended)		//until 1 operation is going on other has to to wait
{
wait();
}
}
}
}
catch(InterruptedException e)
{
System.out.println("Thread in catch"+mythread+"interuption");
}
}

void start()			//start is  a function of thread
{
System.out.println("Start function" +mythread);
if(t==null)			//means no thread is performing write operation i.e. t==null
{
t=new Thread(this,mythread);	//a new memory area is allocated to a thread to carry its operation
t.start();			//start function is called
}
}
void suspend()			
{
suspended=true;
}
synchronized void resume()
{
suspended=false;
notify();
}

}




class testing
{
public static void main(String args[])
{
newthread obj=new newthread("mythread 1");	//constructor call
obj.start();					//automatically on calling "start" method it invokes run method due to its abstract nature
newthread obj1=new newthread("mythread 2");	//constructor call
obj1.start();					//automatically on calling "start" method it invokes run method due to its abstract nature


try
{
Thread.sleep(1000);
obj.suspend ();
System.out.println("Suspending First Thread");
Thread.sleep(1000);
obj.resume ();
System.out.println("Resuming First Thread");
obj1.suspend ();
System.out.println("Suspending 2nd thread ");

Thread.sleep(1000);
obj1.resume ();
System.out.println("Resuming 2nd thread");
} 
catch (InterruptedException e)
 {
System.out.println("1st catch Main thread Interrupted");
}
try 
{
System.out.println("2nd try Waiting for threads to finish.");
obj.t.join();
obj1.t.join();
} 
catch (InterruptedException e)
 {
System.out.println("2nd catch Main thread Interrupted");
}
System.out.println("Main thread exiting.");
}
}
