import java.io.*;

class FileHandling{
	public static void main(String[] args){
		File f = new File("C:/Users/Rahul/Desktop/input.txt");
		File f2 = new File("C:/Users/Rahul/Desktop/output.txt");
		try{
			FileInputStream fin = new FileInputStream(f);
			FileOutputStream fout = new FileOutputStream(f2);
			int x;
			while((x=fin.read())!=-1){
				fout.write(x);
			}
		}
		catch(Exception e){
			e.printStackTrace();  //prints technical info if try fails + inbuilt method
		}
	}	
} 