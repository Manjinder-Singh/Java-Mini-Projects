//overriding method
//In compile time, the check is made on the reference type. 
// in the runtime, JVM figures out the object type and would run
//the method that belongs to that particular object.
class parent
{
public void display()
{
System.out.println("parent class");
}
}
class child extends parent
{
public void display()
{
System.out.println("child class");
}
}
class overridden
{
public static void main(String args[])
{
parent obj=new parent();  //refrence to parent class and its object
parent obj1=new child();  //refrence to parent class and object of child class
obj.display();      //displays parent class method
obj1.display();     //displays child class method
}
}