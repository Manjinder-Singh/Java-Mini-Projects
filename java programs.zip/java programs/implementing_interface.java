interface trying
{
void method1();
void method2();
}
class implementing_interface implements trying
{
public void method1()
{
System.out.println("method1");
}
public void method2()
{
System.out.println("method2");
}
public static void main(String args[])
{
trying obj=new implementing_interface();
obj.method2();
}
}