interface accessing
{
int a=90;
}
class accessing_interface implements accessing
{
int b=a;
void method123(int c)
{
 c=b+10+a+10;
System.out.println("accessing interface:-> " + "value of onterface used in class1 " + c);
}
void method124()
{
 int d=b+10+a;
System.out.println("accessing interface:-> " + "value of onterface used in class2 " + d);
}
public static void main(String args[])
{
accessing_interface obj=new accessing_interface();
obj.method123(23);
obj.method124();
}
}
