﻿//                import java.util.Calendar;
//                import java.util.Date;
//import java.text.DateFormat;
//                import java.text.FieldPosition;
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
//import java.util.Date;
//               import java.util.GregorianCalendar;
class cal
{
public static void main(String args[])
{
System.out.println("try 1:-> ");
//SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
//String date = sdf.format(new Date());
//System.out.println(date);


System.out.println("try 2:-> ");
//SimpleDateFormat sdf2 = new SimpleDateFormat("dd‐M‐yyyy hh:mm:ss");
//String dateInString = "31‐08‐1982 10:20:56";
//Date date2 = sdf2.parse(dateInString);
//System.out.println(date2);

System.out.println("try 3:-> ");
SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
Date date = new Date();
System.out.println(dateFormat.format(date));

System.out.println("working.........");
}
}