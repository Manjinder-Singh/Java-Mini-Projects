class threadfn extends Thread
{
public static void main(String args[])
throws InterruptedException{
String data[]={"shhd ddhh hfhhsd"};
for(int i=0;i<data.length;i++)
{
Thread.sleep(6000);
System.out.println("sleep" + data[i]);
}
}

}
