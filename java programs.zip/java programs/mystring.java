import java.util.Scanner;
class mystring
{
public static void main(String[] args)
{
String a1="rahul";
String a2="rahul";
String a3="singh";
String a4="SAINI";
System.out.println("length of string a1 is:-> " +a1.length());
System.out.println("concatenation:-> " + a1.concat(a3));
System.out.println("comparison:-> " + a1.compareTo(a3));
System.out.println("comparison:-> " + a1.compareToIgnoreCase(a3));
System.out.println("use of + operator for concatenation purpose:-> " + "rahul " + a3 + a4);
//System.out.println(intern(a2));
System.out.println("small letters:-> "+ a4.toLowerCase());
System.out.println("capital letters:-> " + a1.toUpperCase());
System.out.println(a4.toLowerCase());
if(a1.compareTo(a2)>0)
System.out.println("String a1 is grater than a2");
else if(a2.compareTo(a1)>0)
System.out.println("String a2 is grater than a1");
else

System.out.println("String a1 = a2");
String a5,a6;
System.out.println("enter string a5:-> ");
Scanner in =new Scanner(System.in);
a5=in.nextLine();
System.out.println("enter string a6:-> ");
a6=in.nextLine();
//System.out.println("reversed string:-> " + StringBuffer(a5).reverse().toString());
System.out.println("original string:-> " +a5);
a5 = new StringBuffer(a5).reverse().toString();
System.out.println("reversed string:-> " +a5);
System.out.println("trimmed string:-> " + a5.trim());
System.out.println( "returns character at specified index:-> " +a2.charAt(2));
System.out.println( a2.substring(2));
System.out.println( a1.substring(1,3));
}
}

