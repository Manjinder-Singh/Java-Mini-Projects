//First.java  
import java.applet.Applet;  
import java.awt.Graphics;  
public class First extends Applet{  
  
public void paint(Graphics g){  
g.drawString("welcome",150,150);  
}  
  
}  
/* 
<applet code="First.class" width="300" height="300"> 
</applet> 
*/  