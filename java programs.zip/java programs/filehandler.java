import java.io.*;

class filehandler{
	public static void main(String[] args){
		File f = new File("C:/Users/Rahul/Desktop/input.txt");
		File f2 = new File("C:/Users/Rahul/Desktop/output.txt");
		//File f3 = new File("C:/Users/Rahul/Desktop/input1.txt");
		try{
			FileInputStream fin = new FileInputStream(f);
			FileOutputStream fout = new FileOutputStream(f2);
			//FileInputStream fin1 = new FileInputStream(f3);
			int x,y;
			while(((y=fin1.read())!=-1)){
				fout.write(y);
				
			}
		System.out.println("processed....");
		}
		catch(Exception e){
			e.printStackTrace();  //prints technical info if try fails + inbuilt method
		}
	}	
} 
