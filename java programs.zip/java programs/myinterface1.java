//interface is a reference type in java
//similar to class
//	collection of abstract methods
//class implements interface thus extends
//class describes behaviour
//interface defines a way to implement that behaviour 
interface myinterface
{
void show();
}
class myinterface1 implements myinterface
{
int a=4,b=9;
public void show()
{
System.out.println("implementing interface through class:-> " + "showing addition:-> " + (a+b));
}
public static void main(String args[])
{
myinterface1 obj=new myinterface1();
obj.show();
}
}