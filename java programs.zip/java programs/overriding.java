//2
//if we access child class method throught reference to parent class but the accessed method is not present in parent class it will give us error
//if we access child class method through refrence to parent class and the accessed method must declare object of child class.
class parent
{
void name()
{
System.out.println("parent");
}
}
 
class child extends parent
{
void name()
{
System.out.println("child");
}
void roll()
{
System.out.println("child roll");
}
}
class overriding
{
public static void main(String args[])
{
parent obj=new parent();   //refrence to parent class and object + at compile time it will go with parent class and atrun time it will go with parent class object
parent obj1= new  child();  //refrence to parent class and object of child class + at compile time it will go with child class and atrun time it will go with parent class object

obj.name();
obj1.name();
//obj1.roll(); //gives error as obj1 is a object of child class and referencing to parent class and roll is not present in parent class.
//obj.roll();  //gives error as obj is a object of parent class and referencing to parent class and roll is not present in parent class.
}
}
 