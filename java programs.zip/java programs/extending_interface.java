interface a
{
int a=9,b=8;
}
interface b extends a
{
void show();
}
class extending_interface implements a
{
public void show()
{
System.out.println("extending interface:-> "+ "display values:-> " + a + b);
}
public static void main(String args[])
{
extending_interface obj = new extending_interface();
obj.show();
}
}