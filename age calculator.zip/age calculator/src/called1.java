
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rahul
 */
public class called1 {
    private static Object Calender;
    public static void main(String args[]) throws ParseException
    {
       
System.out.println("try 3:-> ");
SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
Date date3 = new Date();
System.out.println(dateFormat.format(date3));


System.out.println("GregorianCalendar");

SimpleDateFormat sdf = new SimpleDateFormat("yyyy MMM dd HH:mm:ss");
//System.out.println(sdf.format(calendar.getTime()));
Calendar calendar = new GregorianCalendar();
System.out.println(sdf.format(calendar.getTime()));      //  System.out.println(calender);
int year = calendar.get(Calendar.YEAR);
int month = calendar.get(Calendar.MONTH); 
int date = calendar.get(Calendar.DATE); 
        System.out.println(year);
        System.out.println(month+1);
System.out.println(date);
    
}
}