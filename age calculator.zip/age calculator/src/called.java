
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rahul
 */
public class called {
    private static Object Calender;
    public static void main(String args[]) throws ParseException
    {
       
//Convert Date to String.
System.out.println("try 1:-> ");
SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
String date1 = sdf.format(new Date());
System.out.println(date1);
System.out.println();

//Convert String to Date.
System.out.println("try 2:-> ");
SimpleDateFormat sdf2 = new SimpleDateFormat("dd‐M‐yyyy hh:mm:ss");
String dateInString = "31‐08‐1982 10:20:56";
Date date2 = sdf2.parse(dateInString);
System.out.println(date2);
System.out.println();

//Get current date time
System.out.println("try 3:-> ");
SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
//Calendar calendar3 = new Calender();
Date date3 = new Date();
//int obj = calendar3.get(Calendar.DATE);
System.out.println(dateFormat.format(date3));
//System.out.println(obj);

System.out.println("working.........");

//Simple Calendar example
System.out.println("try 4:-> ");
SimpleDateFormat sdf4 = new SimpleDateFormat("yyyy MMM dd HH:mm:ss");
Calendar calendar = new GregorianCalendar(2013,1,28,13,24,56);
int year = calendar.get(Calendar.YEAR);
int month = calendar.get(Calendar.MONTH); // Jan = 0, dec = 11
int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
int weekOfYear = calendar.get(Calendar.WEEK_OF_YEAR);
int weekOfMonth= calendar.get(Calendar.WEEK_OF_MONTH);
int hour = calendar.get(Calendar.HOUR); // 12 hour clock
int hourOfDay = calendar.get(Calendar.HOUR_OF_DAY); // 24 hour clock
int minute = calendar.get(Calendar.MINUTE);
int second = calendar.get(Calendar.SECOND);
int millisecond= calendar.get(Calendar.MILLISECOND);
System.out.println(sdf.format(calendar.getTime()));
System.out.println("year \t\t: " + year);
System.out.println("month \t\t: " + month);
System.out.println("dayOfMonth \t: " + dayOfMonth);
System.out.println("dayOfWeek \t: " + dayOfWeek);
System.out.println("weekOfYear \t: " + weekOfYear);
System.out.println("weekOfMonth \t: " + weekOfMonth);
System.out.println("hour \t\t: " + hour);
System.out.println("hourOfDay \t: " + hourOfDay);
System.out.println("minute \t\t: " + minute);
System.out.println("second \t\t: " + second);
System.out.println("millisecond \t: " + millisecond);

//Set a date manually.
System.out.println("try 5:-> ");
SimpleDateFormat sdf5 = new SimpleDateFormat("yyyy MMM dd HH:mm:ss");
Calendar calendar5 = new GregorianCalendar(2013,1,28,13,24,56);
System.out.println("#1. " + sdf5.format(calendar.getTime()));
//update a date
calendar5.set(Calendar.YEAR, 2014);
calendar5.set(Calendar.MONTH, 11);
calendar5.set(Calendar.MINUTE, 33);
System.out.println("#2. " + sdf5.format(calendar5.getTime()));

//add and sub
System.out.println("try 6:-> ");
SimpleDateFormat sdf6 = new SimpleDateFormat("yyyy MMM dd");
Calendar calendar6 = new GregorianCalendar(2013,10,28);
System.out.println("Date : " + sdf6.format(calendar.getTime()));
//add one month
calendar6.add(Calendar.MONTH, 1);
System.out.println("Date : " + sdf6.format(calendar.getTime()));
//subtract 10 days
//calendar6.add(Calendar.DAY_OF_MONTH, (‐10));
System.out.println("Date : " + sdf6.format(calendar6.getTime()));

System.out.println("try 7:-> ");
/*
SimpleDateFormat sdf7 = new SimpleDateFormat("yyyy MMM dd");
Calendar calendar7 = new GregorianCalendar(2013,10,28);
        System.out.println(()-(calendar6.add(Calendar.MONTH, 1)));
   
        */
//    Calender.add(dateFormat.format(date3),-sdf5.format(calendar.getTime()));
 //       System.out.println((dateFormat.format(date3))-(sdf5.format(calendar.getTime())));
    }
}
    
    

